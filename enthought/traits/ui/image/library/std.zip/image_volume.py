from enthought.traits.ui.image.image import ImageVolume, ImageVolumeInfo
    
volume = ImageVolume(
    category    = 'General',
    keywords    = [],
    aliases     = [],
    time_stamp  = '20200101010000',
    info        = [
        ImageVolumeInfo(
            description = 'Standard Traits UI Icons and Themes.',
            copyright   = 'Copyright (c) 2007 by Enthought, Inc.\nAll rights reserved.',
            license     = 'This software is provided without warranty under the terms of the BSD\nlicense included in enthought/LICENSE.txt and may be redistributed only\nunder the conditions described in the aforementioned license.  The license\nis also available online at http://www.enthought.com/licenses/BSD.txt\n\nThanks for using Enthought open source!',
            image_names = []
        )
    ]
)