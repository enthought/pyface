from pyface.image.image import ImageVolume, ImageVolumeInfo

volume = ImageVolume(
    category='General',
    keywords=[],
    aliases=[],
    time_stamp='20230313095529',
    info=[
        ImageVolumeInfo(
            description='No volume description specified.',
            copyright='No copyright information specified.',
            license='No license information specified.',
            image_names=[]
        )
    ]
)